package com.habithatch.demo.data.entities

enum class GoalPriority {
    NORMAL, HIGH
}